# Focus Airlines

A study timer disguised as a flight simulator. Pick a destination, board the plane from Mumbai (BOM), and study until you land. The farther the city, the longer the focus session.

## Features

- 9 destinations (Dubai, Bangkok, Singapore, Paris, London, Tokyo, Sydney, Toronto, New York) with flight time worked out from real great-circle distance
- Adjustable pace (10, 15 or 25 focus minutes per flight hour) and departure time
- 3D cabin window (three.js) showing terrain, clouds, sun and stars that follow the real route, sun position and time of day
- Captain announcements (text and speech), takeoff and landing sounds, cabin hum
- Route map, miles, ranks and a passport of stamps saved in your browser (localStorage)

## Run locally

Open `index.html` in a browser. It is a single static file with no build step. An internet connection is needed to load three.js and the Inter font from CDNs.

## Deploy with GitHub Pages

1. Create a new repository and add `index.html` and `README.md` to the root.
2. Go to **Settings, Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Your site will be live at `https://<your-username>.github.io/<repo-name>/` after a minute or two.

## Tech

Plain HTML, CSS and JavaScript, plus [three.js r128](https://threejs.org/) from cdnjs. Audio uses the Web Audio API and speech uses the browser's SpeechSynthesis.
